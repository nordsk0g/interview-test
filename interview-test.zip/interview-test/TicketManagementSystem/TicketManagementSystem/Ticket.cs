﻿using System;
namespace TicketManagementSystem
{
    public class Ticket
    {
        private string title;
        private string description;

        public int Id { get; set; }

        public string Title
        { 
          get
          {
            return Title;
          }
          set
          {
            if (isEmpty(value))
            {
              throw new InvalidTicketException("Title is null");
            }
            title = value;
          }
        }

        public Priority Priority { get; set; }

        public string Description
        { 
          get
          {
            return Description;
          }
          set
          {
            if (isEmpty(value))
            {
              throw new InvalidTicketException("Description is null");
            }
            description = value;
          }  

        }

        public User AssignedUser { get; set; }

        public User AccountManager { get; set; }

        public DateTime Created { get; set; }

        public double PriceDollars { get; set; }

        public static bool isEmpty(string value)
        {
          return (value == null || value == "");
        }
    }
}
