﻿using System;
using System.Configuration;
using System.IO;
using System.Text.Json;
using EmailService;

namespace TicketManagementSystem
{
    public class TicketService
    {
        private const double HIGH_PRIORITY_PRICE = 100;
        private const double BASE_PRICE = 50;
        private const int MINIMUM_TIME_HOURS = 1;

        public int CreateTicket(string title, Priority p, string assignedTo, string desc, DateTime d, bool isPayingCustomer)
        {
            var ticket = new Ticket()
            {
                Title = title,
                AssignedUser = UserRepository.GetUser(assignedTo),
                Priority = CheckIfPriorityNeedsUpdating(title, d, MINIMUM_TIME_HOURS) ? RaisePriority(p) : p,
                Description = desc,
                Created = d,
                PriceDollars = isPayingCustomer ? SetPrice(p) : 0,
                AccountManager = isPayingCustomer ? UserRepository.GetAccountManager() : null
            };
            
            EmailAdminIfPriorityHigh(p, title, assignedTo);

            return TicketRepository.CreateTicket(ticket);
        }

        public void AssignTicket(int id, string username)
        {
            Ticket ticket = GetTicketFromTicketRepository(id);

            ticket.AssignedUser = UserRepository.GetUser(username);

            TicketRepository.UpdateTicket(ticket);
        }

        private Ticket GetTicketFromTicketRepository(int id)
        {
          var ticket = TicketRepository.GetTicket(id);

          if (ticket == null)
          {
              throw new ApplicationException("No ticket found for id " + id);
          }
          return ticket;
        }

        private bool CheckIfTimeHasExceededLimit(DateTime d, int minimumTime)
        {
          return d < DateTime.UtcNow - TimeSpan.FromHours(minimumTime);
        }

        private bool CheckIfTitleContainsErrorKeywords(string title)
        {
          return title.Contains("Crash") || title.Contains("Important") || title.Contains("Failure");
        }

        private Priority RaisePriority(Priority p)
        {
          if (p == Priority.Low)
          {
            return Priority.Medium;
          }
          return Priority.High;
        }

        private bool CheckIfPriorityNeedsUpdating(string title, DateTime d, int minimumTime)
        {
          return (CheckIfTimeHasExceededLimit(d, minimumTime) || CheckIfTitleContainsErrorKeywords(title));
        }

        private void EmailAdminIfPriorityHigh(Priority p, string title, string assignedTo) {
          if (p == Priority.High)
            {
                var emailService = new EmailServiceProxy();
                emailService.SendEmailToAdministrator(title, assignedTo);
            }
        }

        private double SetPrice(Priority p)
        {
          if (p == Priority.High)
          {
              return HIGH_PRIORITY_PRICE;
          }
          return BASE_PRICE;
        }
        private void WriteTicketToFile(Ticket ticket)
        {
            var ticketJson = JsonSerializer.Serialize(ticket);
            File.WriteAllText(Path.Combine(Path.GetTempPath(), $"ticket_{ticket.Id}.json"), ticketJson);
        }
    }

    public enum Priority
    {
        High,
        Medium,
        Low
    }
}
